from pathlib import Path
from types import SimpleNamespace

import pytest
from fastapi import HTTPException

from app.auth import routes


class _Chain:
    def update(self, *_args, **_kwargs):
        return self

    def insert(self, *_args, **_kwargs):
        return self

    def upsert(self, *_args, **_kwargs):
        return self

    def eq(self, *_args, **_kwargs):
        return self

    def is_(self, *_args, **_kwargs):
        return self

    def execute(self):
        return SimpleNamespace(data=[])


class _Database:
    def table(self, *_args, **_kwargs):
        return _Chain()


class _RecordingDatabase:
    def __init__(self):
        self.updates = []

    def table(self, name):
        database = self

        class Chain(_Chain):
            def update(self, payload, *_args, **_kwargs):
                database.updates.append((name, payload))
                return self

            def insert(self, payload, *_args, **_kwargs):
                database.updates.append((name, {"insert": payload}))
                return self

        return Chain()


@pytest.mark.asyncio
async def test_register_returns_generic_503_when_email_delivery_fails(monkeypatch):
    monkeypatch.setattr(routes, "get_user_by_email", lambda _email: {"id": "test-user", "email_verified": False})
    monkeypatch.setattr(routes, "supabase", _Database())
    monkeypatch.setattr(routes, "send_otp_via_emailjs", lambda *_args, **_kwargs: {"success": False})

    with pytest.raises(HTTPException) as error:
        await routes.register(
            routes.RegisterRequest(
                email="test@example.com",
                password="a" * 12,
                display_name="Test User",
            )
        )

    assert error.value.status_code == 503
    assert "EmailJS" not in str(error.value.detail)
    assert "provider" not in str(error.value.detail)


def test_email_delivery_failure_consumes_inserted_otp(monkeypatch):
    database = _RecordingDatabase()
    monkeypatch.setattr(routes, "supabase", database)
    monkeypatch.setattr(routes, "send_otp_via_emailjs", lambda *_args, **_kwargs: {"success": False})

    with pytest.raises(routes.EmailDeliveryError):
        routes._issue_email_otp("test-user", "test@example.com", "signup")

    assert any(
        table == "custom_auth_otps" and "consumed_at" in payload
        for table, payload in database.updates
    )


def test_auth_openapi_contains_resend_otp_path():
    from app.main import app

    assert "/api/v1/auth/resend-otp" in app.openapi()["paths"]


def test_register_does_not_write_legacy_user_profiles():
    source = Path("backend/app/auth/routes.py").read_text(encoding="utf-8")
    assert 'table("user_profiles")' not in source
