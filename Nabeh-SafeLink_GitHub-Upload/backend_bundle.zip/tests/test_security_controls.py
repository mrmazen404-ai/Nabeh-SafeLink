import pytest

from app.gemini.schemas import validate_gemini_payload
from app.security.guest_rate_limit import RateLimitDecision, UpstashRateLimiter


def test_gemini_schema_drops_untrusted_extra_fields_and_html():
    result = validate_gemini_payload(
        {
            "summary": "<b>تحليل</b> آمن",
            "recommendation": "لا تدخل بياناتك",
            "reasons": ["سبب أول", ""],
            "limitations": [],
        },
        fallback={"summary": "fallback", "recommendation": "caution"},
    )

    assert result["summary"] == "تحليل آمن"

    rejected = validate_gemini_payload(
        {
            "summary": "تحليل",
            "recommendation": "حذر",
            "unexpected_secret": "must not reach the UI",
        },
        fallback={"summary": "fallback", "recommendation": "caution"},
    )
    assert rejected["summary"] == "fallback"
    assert rejected["reasons"] == []
    assert "unexpected_secret" not in rejected
    assert rejected["limitations"] == ["تم استخدام التفسير المحلي لأن مخرجات مزود الذكاء الاصطناعي غير صالحة."]


def test_gemini_schema_bounds_untrusted_lists():
    result = validate_gemini_payload(
        {
            "summary": "تحليل",
            "recommendation": "حذر",
            "reasons": [f"reason-{i}" for i in range(20)],
            "limitations": [],
        },
        fallback={"summary": "fallback", "recommendation": "caution"},
    )

    # More than five reasons is invalid and must use the safe fallback.
    assert result["limitations"]
    assert len(result["reasons"]) == 0


@pytest.mark.asyncio
async def test_unconfigured_limiter_is_available_for_local_development():
    limiter = UpstashRateLimiter(url="", token="", limit=2, window_seconds=60)
    decision = await limiter.check("127.0.0.1")
    assert decision.allowed is True
    assert decision.remaining == 2


def test_rate_limit_decision_contract():
    decision = RateLimitDecision(False, 10, 0, 42)
    assert decision.allowed is False
    assert decision.retry_after == 42
