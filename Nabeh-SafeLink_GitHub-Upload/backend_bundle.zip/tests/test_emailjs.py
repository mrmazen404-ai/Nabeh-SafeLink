from unittest.mock import Mock

from app.auth import emailjs


def test_emailjs_reads_runtime_environment_without_exposing_secrets(monkeypatch):
    monkeypatch.setenv("EMAILJS_SERVICE_ID", "service-test")
    monkeypatch.setenv("EMAILJS_TEMPLATE_ID", "template-test")
    monkeypatch.setenv("EMAILJS_PUBLIC_KEY", "public-test")
    monkeypatch.setenv("EMAILJS_PRIVATE_KEY", "private-test")

    response = Mock(status_code=200)
    request = Mock(return_value=response)
    monkeypatch.setattr(emailjs.requests, "post", request)

    result = emailjs.send_otp_via_emailjs("user@example.com", "123456")

    assert result == {"success": True}
    payload = request.call_args.kwargs["json"]
    assert payload["service_id"] == "service-test"
    assert payload["template_id"] == "template-test"
    assert payload["template_params"]["email"] == "user@example.com"
    assert payload["template_params"]["otp"] == "123456"


def test_emailjs_classifies_server_access_disabled(monkeypatch):
    monkeypatch.setenv("EMAILJS_SERVICE_ID", "service-test")
    monkeypatch.setenv("EMAILJS_TEMPLATE_ID", "template-test")
    monkeypatch.setenv("EMAILJS_PUBLIC_KEY", "public-test")
    monkeypatch.setenv("EMAILJS_PRIVATE_KEY", "private-test")
    response = Mock(status_code=403)
    monkeypatch.setattr(emailjs.requests, "post", Mock(return_value=response))

    assert emailjs.send_otp_via_emailjs("user@example.com", "123456")["error"] == "email_provider_server_access_disabled"


def test_emailjs_classifies_bad_request(monkeypatch):
    for name, value in {
        "EMAILJS_SERVICE_ID": "service-test",
        "EMAILJS_TEMPLATE_ID": "template-test",
        "EMAILJS_PUBLIC_KEY": "public-test",
        "EMAILJS_PRIVATE_KEY": "private-test",
    }.items():
        monkeypatch.setenv(name, value)
    response = Mock(status_code=400, text="The template is not configured")
    monkeypatch.setattr(emailjs.requests, "post", Mock(return_value=response))

    assert emailjs.send_otp_via_emailjs("user@example.com", "123456")["error"] == "email_provider_bad_request"


def test_emailjs_classifies_rate_limit(monkeypatch):
    for name, value in {
        "EMAILJS_SERVICE_ID": "service-test",
        "EMAILJS_TEMPLATE_ID": "template-test",
        "EMAILJS_PUBLIC_KEY": "public-test",
        "EMAILJS_PRIVATE_KEY": "private-test",
    }.items():
        monkeypatch.setenv(name, value)
    response = Mock(status_code=429, text="Too many requests")
    monkeypatch.setattr(emailjs.requests, "post", Mock(return_value=response))

    assert emailjs.send_otp_via_emailjs("user@example.com", "123456")["error"] == "email_provider_rate_limited"
