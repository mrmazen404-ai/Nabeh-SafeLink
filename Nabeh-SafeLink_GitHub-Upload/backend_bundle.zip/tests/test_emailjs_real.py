"""Safe one-message EmailJS test for Nabeh SafeLink.

The script reads server-side environment variables only. It never belongs in the
frontend and supports a configuration-only mode that does not send email.
"""

from __future__ import annotations

import argparse
import os
import re
import sys
from pathlib import Path

import requests
from dotenv import load_dotenv

EMAILJS_URL = "https://api.emailjs.com/api/v1.0/email/send"
DEFAULT_RECIPIENT = "mr.mazenn404@gmail.com"
PROJECT_ROOT = Path(__file__).resolve().parents[2]


def load_environment() -> None:
    env_file = PROJECT_ROOT / ".env"
    if env_file.is_file():
        load_dotenv(env_file, override=False)


def required(name: str) -> str:
    value = os.getenv(name, "").strip()
    if not value:
        raise SystemExit(f"Missing environment variable: {name}")
    return value


def configuration() -> dict[str, str]:
    service_id = required("EMAILJS_SERVICE_ID")
    template_id = required("EMAILJS_TEMPLATE_ID")
    public_key = required("EMAILJS_PUBLIC_KEY")
    private_key = required("EMAILJS_PRIVATE_KEY")
    if not re.fullmatch(r"service_[A-Za-z0-9_-]+", service_id):
        raise SystemExit("EMAILJS_SERVICE_ID has an invalid format")
    if not re.fullmatch(r"template_[A-Za-z0-9_-]+", template_id):
        raise SystemExit("EMAILJS_TEMPLATE_ID has an invalid format")
    if not public_key or len(private_key) < 8:
        raise SystemExit("EmailJS key configuration is incomplete")
    return {
        "service_id": service_id,
        "template_id": template_id,
        "public_key": public_key,
        "private_key": private_key,
    }


def build_payload(config: dict[str, str], recipient: str) -> dict:
    return {
        "service_id": config["service_id"],
        "template_id": config["template_id"],
        "user_id": config["public_key"],
        "accessToken": config["private_key"],
        "template_params": {
            # The EmailJS template's To Email field must be exactly {{email}}.
            "email": recipient,
            "to_name": recipient.split("@", 1)[0],
            "otp": "123456",
            "subject": "اختبار EmailJS — Nabeh SafeLink",
            "app_name": "Nabeh SafeLink",
            "action_type": "اختبار الإرسال",
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--check-only", action="store_true")
    parser.add_argument("--recipient", default=DEFAULT_RECIPIENT)
    args = parser.parse_args()

    load_environment()
    config = configuration()
    print(f"EmailJS configuration loaded: service/template configured")
    print(f"Recipient: {args.recipient}")
    print("Template recipient variable: {{email}}")

    if args.check_only:
        print("Configuration valid; no email was sent.")
        return 0

    response = requests.post(
        EMAILJS_URL,
        json=build_payload(config, args.recipient),
        headers={"Content-Type": "application/json"},
        timeout=20,
    )
    print(f"HTTP status: {response.status_code}")
    print(f"EmailJS response: {(response.text or 'OK')[:500]}")
    if response.status_code == 200:
        print("One real test email was accepted by EmailJS.")
        return 0
    print("EmailJS rejected the message; no success is claimed.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
