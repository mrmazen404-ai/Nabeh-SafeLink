from typing import Optional

from fastapi import APIRouter, Header, HTTPException, Response

from app.db.supabase_client import supabase
from app.observability import log_event
from app.scans.routes import get_required_user_id

import logging

logger = logging.getLogger(__name__)

router = APIRouter()


@router.get("/me")
async def get_my_statistics(
    response: Response,
    authorization: Optional[str] = Header(None),
):
    response.headers["Cache-Control"] = "no-store, private"
    response.headers["Pragma"] = "no-cache"
    user_id = await get_required_user_id(authorization)

    try:
        result = (
            supabase.table("scans")
            .select("classification")
            .eq("user_id", user_id)
            .execute()
        )
        scans = result.data or []
        log_event(logger, logging.INFO, "statistics_loaded", total=len(scans))
    except Exception:
        log_event(logger, logging.ERROR, "statistics_load_failed")
        raise HTTPException(status_code=503, detail="تعذر تحميل الإحصاءات") from None

    return {
        "success": True,
        "data": {
            "total": len(scans),
            "safe": sum(1 for scan in scans if scan.get("classification") == "SAFE"),
            "suspicious": sum(1 for scan in scans if scan.get("classification") == "SUSPICIOUS"),
            "dangerous": sum(1 for scan in scans if scan.get("classification") == "DANGEROUS"),
        },
    }
