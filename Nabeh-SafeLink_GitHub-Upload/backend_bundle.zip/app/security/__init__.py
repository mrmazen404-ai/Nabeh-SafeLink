"""Security controls for public and authenticated API paths."""
